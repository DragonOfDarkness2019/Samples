﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Dragon : MonoBehaviour {

	public int health = 1000;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	public bool isDead = false;
	public float hangtime;
	public Sprite[] sprites;

	int deathTimer;

	static public Dragon dragon;

	// Use this for initialization
	void Start () {
		dragon = this;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		if (isRed > 0) {
			isRed = isRed + 1;
			if (isRed > 5) {
				hitFlash.color = new Color (1f, 1f, 1f, 1f);
				isRed = 0;
			}
		}
		if (isDead== true) {
			hitFlash.color = new Color(0.5f, 1f, 0.5f, 1f);
			deathTimer++;
			if (deathTimer >= 20) {
				Time.timeScale = 0;
			}
			if (deathTimer >= 100) {
				Time.timeScale = 1;
				SceneManager.LoadScene ("Game Over");
			}
			if (sprites != null) {
				this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
			}
			//rigidBody.velocity = transform.up * 0; //Jumping stops
			//rigidBody.velocity = transform.right * -5; //moves left; since the sprite has been rotated to face upwards,
													   //this makes him fall to the ground
	}

	} //Update

	public void TakeDamage (int damage)
	{
		hitFlash.color = new Color(1f, 0.5f, 0.5f, 1f);
		isRed = 1;
		health -= damage;
		//audioData.Play (0);
		if (health <= 0) {
			DragonDie ();
		}
	} //TakeDamage

	void DragonDie ()
	{
		isDead = true;
		transform.Rotate (new Vector3 (0, 0, 90));

	} //DragonDie
}
