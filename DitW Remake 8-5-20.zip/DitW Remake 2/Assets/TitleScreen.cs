﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class TitleScreen : MonoBehaviour {

	public string gameSceneName="Scene-1";


	// Use this for initialization
	void Start () {
		
	} //Start


	
	// Update is called once per frame
	void Update () {


		if (Input.GetKeyUp (KeyCode.Return)) {
			SceneManager.LoadScene(gameSceneName);
		}


	}// Update
}
