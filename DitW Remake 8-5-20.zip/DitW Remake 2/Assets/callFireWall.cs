﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CallFireWall : MonoBehaviour {

	public int timer;
	public Transform firePoint;
	public GameObject Firewall;

	static public int bolts;

	// Use this for initialization
	void Start () {
		timer = 100;
	} //Start()

	// Update is called once per frame
	void Update () {
		timer--;
		print (timer);
		if (timer <= 0) {
			//Time.timeScale = 0;
			bolts = 0;
			//callLightning ();
			//fireWall();
			Destroy (gameObject);
			//Time.timeScale = 1;
			DruidShooting.isShooting = 0;
		}
	} //Update()

	/*void callLightning()
	{
		Vector3 loc = markPoint.position;
		//Instantiate (zappyZap, markPoint.position, markPoint.rotation);
		loc.y = loc.y + 6.2f;
		loc.x = loc.x + 6.2f;
		//print (temp-1);
		Instantiate (Lightning, loc, Quaternion.identity);
		
	} //callLightning() */
}
